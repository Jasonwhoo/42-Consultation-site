
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { Instagram } from "lucide-react";

export default function HomePage() {
  return (
    <main className="p-6 space-y-8 bg-blue-50 min-h-screen">
      {/* Header */}
      <header className="text-center relative">
        <Image
          src="/42Logo.png"
          alt="42 Consultation Logo"
          width={100}
          height={100}
          className="mx-auto"
        />
        <h1 className="text-4xl font-bold text-blue-900 mt-4">42 Consultation</h1>
        <p className="text-lg text-blue-700">Curating Restaurant Excellence Across India</p>
        <a
          href="https://www.instagram.com/42_consultation?igsh=bmk5NTN5d2szNzkz&utm_source=qr"
          target="_blank"
          className="absolute top-4 right-4 text-blue-700 hover:text-blue-900"
        >
          <Instagram className="w-6 h-6" />
        </a>
      </header>

      {/* About */}
      <section className="text-center max-w-2xl mx-auto">
        <h2 className="text-2xl font-semibold mb-2 text-blue-800">About Us</h2>
        <p className="text-gray-700">
          At 42 Consultation, we specialize in concept creation, R&D, kitchen operations, and
          launching standout restaurants. From Japanese Nikkei dining to fun fusion taquerias,
          our team transforms ideas into immersive culinary experiences.
        </p>
      </section>

      {/* Services */}
      <section>
        <h2 className="text-2xl font-semibold text-center text-blue-800 mb-4">Our Services</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              title: "Concept Creation",
              detail: "From blank canvas to bold identity—we build your restaurant's unique story and style."
            },
            {
              title: "Menu R&D",
              detail: "We develop distinctive, operationally viable menus tailored to your market and vision."
            },
            {
              title: "Kitchen Design & Setup",
              detail: "Smart layouts, smooth flow, and optimal equipment selection for consistent service."
            },
            {
              title: "Hiring & Training",
              detail: "We help you build a sharp, passionate team and train them for seamless execution."
            },
            {
              title: "Pre-Opening Management",
              detail: "Countdown to launch? We streamline everything—trial runs, setup, and opening day support."
            },
            {
              title: "Ongoing Ops Support",
              detail: "Post-opening audits, menu refreshes, and strategic insight to keep your concept evolving."
            }
          ].map((service, index) => (
            <Card key={index} className="shadow-md">
              <CardContent className="p-4">
                <h3 className="text-lg font-bold text-blue-900 mb-2">{service.title}</h3>
                <p className="text-gray-700">{service.detail}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Team */}
      <section>
        <h2 className="text-2xl font-semibold text-center text-blue-800 mb-4">Meet the Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              name: "Rishikesh Sagvekar",
              title: "Sous Chef"
            },
            {
              name: "Huzefa Aatif Kakajiwalla",
              title: "Jr Sous Chef"
            },
            {
              name: "Priti Yadva",
              title: "Personal Assistant"
            }
          ].map((member, index) => (
            <Card key={index} className="shadow-md">
              <CardContent className="p-4 text-center">
                <h3 className="text-lg font-bold text-blue-900 mb-1">{member.name}</h3>
                <p className="text-gray-700 italic">{member.title}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Blog */}
      <section>
        <h2 className="text-2xl font-semibold text-center text-blue-800 mb-4">Insights & Updates</h2>
        <div className="text-center text-gray-600 italic">
          <p>Blog section coming soon. This will be editable for real-time updates, stories, and news.</p>
        </div>
      </section>

      {/* Photo Gallery */}
      <section>
        <h2 className="text-2xl font-semibold text-center text-blue-800 mb-4">Gallery</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            "/CD_Otoki_Mar_25_621.tiff"
          ].map((src, index) => (
            <div key={index} className="overflow-hidden rounded-lg shadow-md">
              <Image
                src={src}
                alt={`Project Photo ${index + 1}`}
                width={600}
                height={400}
                className="object-cover w-full h-full"
              />
            </div>
          ))}
        </div>
      </section>

      {/* Restaurants */}
      <section>
        <h2 className="text-2xl font-semibold text-center text-blue-800 mb-4">Our Projects</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              name: "Otoki Mumbai",
              desc: "A modern Japanese Nikkei restaurant fusing playful ceviches, robata grills, and tableside experiences."
            },
            {
              name: "Hacienda Bangalore",
              desc: "An elegant yet approachable dining space with a focus on Alpine French-Swiss cuisine."
            },
            {
              name: "Rotico",
              desc: "A colorful, family-friendly taqueria concept blending Indian & Mexican flavors for dine-in and delivery."
            },
            {
              name: "Leo Mumbai",
              desc: "A modern, youthful space celebrating bold global flavors and smart casual energy."
            },
            {
              name: "Pompa",
              desc: "Consulting and operations management partner – elevating every service moment from back to front."
            }
          ].map((resto, index) => (
            <Card key={index} className="shadow-lg">
              <CardContent className="p-4">
                <h3 className="text-xl font-bold text-blue-900 mb-2">{resto.name}</h3>
                <p className="text-gray-700">{resto.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="text-center mt-12">
        <h2 className="text-2xl font-semibold text-blue-800 mb-2">Let's Work Together</h2>
        <p className="text-gray-700 mb-4">Looking to bring your restaurant vision to life? Get in touch.</p>
        <a href="mailto:jason@42consultation.com">
          <Button className="bg-blue-800 hover:bg-blue-900 text-white">Contact Us</Button>
        </a>
        <p className="text-sm text-gray-600 mt-2">
          or email us directly at <a href="mailto:jason@42consultation.com" className="text-blue-800 underline">jason@42consultation.com</a>
        </p>
        <p className="text-sm text-gray-600 mt-2">
          Follow us on Instagram: <a href="https://www.instagram.com/42_consultation?igsh=bmk5NTN5d2szNzkz&utm_source=qr" target="_blank" className="text-blue-800 underline">@42_consultation</a>
        </p>
        <p className="text-sm text-gray-600 mt-2">
          Connect on LinkedIn: <a href="https://www.linkedin.com/company/94811031" target="_blank" className="text-blue-800 underline">42 Consultation on LinkedIn</a>
        </p>
      </section>
    </main>
  );
}
